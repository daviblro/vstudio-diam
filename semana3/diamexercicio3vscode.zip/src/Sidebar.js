import React from "react";
import './style.css';

function Sidebar() {
  return (
    <nav class="sidebar">
      <a href="index.html"><h2>Home</h2></a>
      <a href="index.html"><h2>Formulário</h2></a>
      <a href="index.html"><h2>Agenda</h2></a>
    </nav>
  );
}
export default Sidebar;
